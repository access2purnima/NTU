package purnima.indianfoodrecipe;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;

public class GoaRecipesActivity extends AppCompatActivity{

    RelativeLayout lay_recipe1;
    RelativeLayout lay_recipe2;
    RelativeLayout lay_recipe3;
    RelativeLayout lay_recipe4;
    RelativeLayout lay_recipe5;

    String recipe_title=null,recipe_shortdescription = null, about_recipe = null, recipe_ingredients = null, recipe_makinginstructions = null;
    String recipe_makingvideoURL=null;
    String recipe_imagename=null;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goarecipes);
        Intent intentgoa=getIntent();

        lay_recipe1 = (RelativeLayout) findViewById(R.id.lay1);
        lay_recipe2 = (RelativeLayout) findViewById(R.id.lay2);
        lay_recipe3 = (RelativeLayout) findViewById(R.id.lay3);
        lay_recipe4 = (RelativeLayout) findViewById(R.id.lay4);
        lay_recipe5 = (RelativeLayout) findViewById(R.id.lay5);

        getSupportActionBar().setTitle(getString(R.string.app_name));

        lay_recipe1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.GoanShrimpCurry_title);
                recipe_imagename="goanshrimpcurry";
                recipe_shortdescription = getResources().getString(R.string.GoanShrimpCurry_shortdescription);
                about_recipe = getResources().getString(R.string.GoanShrimpCurry_recipetype);
                recipe_ingredients = getResources().getString(R.string.GoanShrimpCurry_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.GoanShrimpCurry_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.GoanShrimpCurry_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.FishFingers_title);
                recipe_imagename="fishfingers";
                recipe_shortdescription = getResources().getString(R.string.FishFingers_shortdescription);
                about_recipe = getResources().getString(R.string.FishFingers_recipetype);
                recipe_ingredients = getResources().getString(R.string.FishFingers_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.FishFingers_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.FishFingers_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.PepperChilliPrawns_title);
                recipe_imagename="pepperchilliprawn";
                recipe_shortdescription = getResources().getString(R.string.PepperChilliPrawns_shortdescription);
                about_recipe = getResources().getString(R.string.PepperChilliPrawns_recipetype);
                recipe_ingredients = getResources().getString(R.string.PepperChilliPrawns_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.PepperChilliPrawns_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.PepperChilliPrawns_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.Prawnbalchao_title);
                recipe_imagename="prawnbalchao";
                recipe_shortdescription = getResources().getString(R.string.Prawnbalchao_shortdescription);
                about_recipe = getResources().getString(R.string.Prawnbalchao_recipetype);
                recipe_ingredients = getResources().getString(R.string.Prawnbalchao_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.Prawnbalchao_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.Prawnbalchao_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.RosOmlette_title);
                recipe_imagename="roseomlette";
                recipe_shortdescription = getResources().getString(R.string.RosOmlette_shortdescription);
                about_recipe = getResources().getString(R.string.RosOmlette_recipetype);
                recipe_ingredients = getResources().getString(R.string.RosOmlette_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.RosOmlette_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.RosOmlett_makingvideoURL);
                callingActivity();
            }
        });
    }

    public void callingActivity() {
        Intent intentrecipemaking = new Intent(GoaRecipesActivity.this, RecipeMakingActivity.class);
        intentrecipemaking.putExtra("recipe_title", recipe_title);
        intentrecipemaking.putExtra("recipe_imagename", recipe_imagename);
        intentrecipemaking.putExtra("recipe_shortdescription", recipe_shortdescription);
        intentrecipemaking.putExtra("about_recipe", about_recipe);
        intentrecipemaking.putExtra("recipe_ingredients", recipe_ingredients);
        intentrecipemaking.putExtra("recipe_makinginstructions", recipe_makinginstructions);
        intentrecipemaking.putExtra("recipe_makingvideoURL", recipe_makingvideoURL);
        startActivity(intentrecipemaking);
    }
}
