package purnima.indianfoodrecipe;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;

public class MumbaiRecipesActivity extends AppCompatActivity{

    RelativeLayout lay_recipe1;
    RelativeLayout lay_recipe2;
    RelativeLayout lay_recipe3;
    RelativeLayout lay_recipe4;
    RelativeLayout lay_recipe5;
    RelativeLayout lay_recipe6;
    RelativeLayout lay_recipe7;

    String recipe_title=null,recipe_shortdescription = null, about_recipe = null, recipe_ingredients = null, recipe_makinginstructions = null;
    String recipe_makingvideoURL=null;
    String recipe_imagename=null;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mumbairecipes);
        Intent intentmumbai=getIntent();

        lay_recipe1 = (RelativeLayout) findViewById(R.id.lay1);
        lay_recipe2 = (RelativeLayout) findViewById(R.id.lay2);
        lay_recipe3 = (RelativeLayout) findViewById(R.id.lay3);
        lay_recipe4 = (RelativeLayout) findViewById(R.id.lay4);
        lay_recipe5 = (RelativeLayout) findViewById(R.id.lay5);
        lay_recipe6 = (RelativeLayout) findViewById(R.id.lay6);
        lay_recipe7 = (RelativeLayout) findViewById(R.id.lay7);

        getSupportActionBar().setTitle(getString(R.string.app_name));

        lay_recipe1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.Pavbhajji_title);
                recipe_imagename="pavbhajji";
                recipe_shortdescription = getResources().getString(R.string.Pavbhajji_shortdescription);
                about_recipe = getResources().getString(R.string.Pavbhajji_recipetype);
                recipe_ingredients = getResources().getString(R.string.Pavbhajji_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.Pavbhajji_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.Pavbhajji_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.GINGERCHICKEN_title);
                recipe_imagename="gingerchicken";
                recipe_shortdescription = getResources().getString(R.string.GINGERCHICKEN_shortdescription);
                about_recipe = getResources().getString(R.string.GINGERCHICKEN_recipetype);
                recipe_ingredients = getResources().getString(R.string.GINGERCHICKEN_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.GINGERCHICKEN_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.GINGERCHICKEN_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.MysorePak_title);
                recipe_imagename="mysorepak";
                recipe_shortdescription = getResources().getString(R.string.MysorePak_shortdescription);
                about_recipe = getResources().getString(R.string.MysorePak_recipetype);
                recipe_ingredients = getResources().getString(R.string.MysorePak_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.MysorePak_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.MysorePak_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.Tomatorice_title);
                recipe_imagename="tomotorice";
                recipe_shortdescription = getResources().getString(R.string.Tomatorice_shortdescription);
                about_recipe = getResources().getString(R.string.Tomatorice_recipetype);
                recipe_ingredients = getResources().getString(R.string.Tomatorice_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.Tomatorice_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.Tomatorice_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.VegetableCutlet_title);
                recipe_imagename="vegetablecutlet";
                recipe_shortdescription = getResources().getString(R.string.VegetableCutlet_shortdescription);
                about_recipe = getResources().getString(R.string.VegetableCutlet_recipetype);
                recipe_ingredients = getResources().getString(R.string.VegetableCutlet_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.VegetableCutlet_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.VegetableCutlet_makingvideoURL);
                callingActivity();
            }
        });

    }

    public void callingActivity() {
        Intent intentrecipemaking = new Intent(MumbaiRecipesActivity.this, RecipeMakingActivity.class);
        intentrecipemaking.putExtra("recipe_title", recipe_title);
        intentrecipemaking.putExtra("recipe_imagename", recipe_imagename);
        intentrecipemaking.putExtra("recipe_shortdescription", recipe_shortdescription);
        intentrecipemaking.putExtra("about_recipe", about_recipe);
        intentrecipemaking.putExtra("recipe_ingredients", recipe_ingredients);
        intentrecipemaking.putExtra("recipe_makinginstructions", recipe_makinginstructions);
        intentrecipemaking.putExtra("recipe_makingvideoURL", recipe_makingvideoURL);
        startActivity(intentrecipemaking);
    }
}
