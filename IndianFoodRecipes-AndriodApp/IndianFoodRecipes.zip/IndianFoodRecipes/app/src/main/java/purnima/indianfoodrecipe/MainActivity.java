package purnima.indianfoodrecipe;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.content.Intent;

public class MainActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnFindRecipes = (Button) findViewById(R.id.homepagebutton);

        btnFindRecipes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentregions = new Intent(MainActivity.this, RegionsActivity.class);
                startActivity(intentregions);
            }
        });
    }
}

