package purnima.indianfoodrecipe;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class RegionsActivity extends AppCompatActivity{

    Button button_andhra;
    Button button_hyderabad;
    Button button_mumbai;
    Button button_goa;
    Button button_kerala;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regions);

        Intent intent=getIntent();

        button_andhra = (Button) findViewById(R.id.button_andhrapradesh);
        button_hyderabad = (Button) findViewById(R.id.button_hyderabad);
        button_mumbai = (Button) findViewById(R.id.button_mumbai);
        button_goa = (Button) findViewById(R.id.button_goa);
        button_kerala = (Button) findViewById(R.id.button_kerala);

        button_hyderabad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { hyderabadrecipesActivity();
            }
        });

        button_mumbai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mumbairecipesActivity();
            }
        });

        button_goa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goarecipesActivity();
            }
        });

        button_kerala.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keralarecipesActivity();
            }
        });

        button_andhra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                andhrarecipesActivity();
            }
        });
    }

    public void andhrarecipesActivity(){
        Intent intentandhra = new Intent(RegionsActivity.this,AndhraRecipesActivity.class);
        startActivity(intentandhra);
    }

    public void hyderabadrecipesActivity(){
        Intent intenthyderabad = new Intent(RegionsActivity.this,HyderabadRecipesActivity.class);
        startActivity(intenthyderabad);
    }

    public void mumbairecipesActivity(){
        Intent intentmumbai = new Intent(RegionsActivity.this,MumbaiRecipesActivity.class);
        startActivity(intentmumbai);
    }

    public void keralarecipesActivity(){
        Intent intentkerala = new Intent(RegionsActivity.this,KeralaRecipesActivity.class);
        startActivity(intentkerala);
    }

    public void goarecipesActivity(){
        Intent intentgoa = new Intent(RegionsActivity.this,GoaRecipesActivity.class);
        startActivity(intentgoa);
    }
}
