package purnima.indianfoodrecipe;

import android.annotation.TargetApi;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import android.net.Uri;
import android.content.Intent;

public class RecipeMakingActivity extends AppCompatActivity {

    ImageView thumbnail;
    TextView txtTitle;
    TextView txtMaking1;
    TextView txtMaking2;
    TextView txtMaking3;
    TextView txtMaking4;
    Button btnMakingVideo;

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_making);

        thumbnail=(ImageView)findViewById(R.id.thumbnail);
        txtTitle=(TextView)findViewById(R.id.recipe_title);
        txtMaking1=(TextView)findViewById(R.id.recipe_making1);
        txtMaking2=(TextView)findViewById(R.id.recipe_making2);
        txtMaking3=(TextView)findViewById(R.id.recipe_making3);
        txtMaking4=(TextView)findViewById(R.id.recipe_making4);

        btnMakingVideo = (Button) findViewById(R.id.recipe_makingvideo);

        String imagename;
        int imageresid = 0;

        Drawable thumbnailimage;

        getSupportActionBar().setTitle(getIntent().getStringExtra("recipe_title"));

        txtTitle.setText(getIntent().getStringExtra("recipe_title"));

        if (!TextUtils.isEmpty(getIntent().getStringExtra("recipe_imagename"))){
            try {
                imagename = getIntent().getStringExtra("recipe_imagename");
                imageresid = getResources().getIdentifier(imagename, "drawable", getPackageName());
                thumbnailimage = (Drawable) getResources().getDrawable(imageresid);
                thumbnail.setBackground(thumbnailimage);
            }
            catch(Exception e) {
                thumbnail.setVisibility(View.GONE);
            }
        }else{
            thumbnail.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(getIntent().getStringExtra("recipe_shortdescription"))){
            txtMaking1.setText(getIntent().getStringExtra("recipe_shortdescription"));
        }else{
            txtMaking1.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(getIntent().getStringExtra("recipe_makingvideoURL"))){
                    btnMakingVideo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        watchrecipemakingvideo();
                    }
                });
        }else{
            btnMakingVideo.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(getIntent().getStringExtra("about_recipe"))){
            txtMaking2.setText(getIntent().getStringExtra("about_recipe"));
        }else{
            txtMaking2.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(getIntent().getStringExtra("recipe_ingredients"))){
            txtMaking3.setText(getIntent().getStringExtra("recipe_ingredients"));
        }else{
            txtMaking3.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(getIntent().getStringExtra("recipe_makinginstructions"))){
            txtMaking4.setText(getIntent().getStringExtra("recipe_makinginstructions"));
        }else{
            txtMaking4.setVisibility(View.GONE);
        }
    }

    public void watchrecipemakingvideo() {
        try {
            Uri videoUri = Uri.parse(getIntent().getStringExtra("recipe_makingvideoURL"));
            Intent intentrecipemakingvideo = new Intent(Intent.ACTION_VIEW, videoUri);
            startActivity(intentrecipemakingvideo);
        }
        catch(Exception e) {
        }
    }
}
