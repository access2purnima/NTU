package purnima.indianfoodrecipe;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;

public class AndhraRecipesActivity extends AppCompatActivity{

    RelativeLayout lay_recipe1;
    RelativeLayout lay_recipe2;
    RelativeLayout lay_recipe3;
    RelativeLayout lay_recipe4;
    RelativeLayout lay_recipe5;
    RelativeLayout lay_recipe6;
    RelativeLayout lay_recipe7;

    String recipe_title=null,recipe_shortdescription = null, about_recipe = null, recipe_ingredients = null, recipe_makinginstructions = null;
    String recipe_makingvideoURL=null;
    String recipe_imagename=null;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_andhrarecipes);
        Intent intentandhra=getIntent();

        lay_recipe1 = (RelativeLayout) findViewById(R.id.lay1);
        lay_recipe2 = (RelativeLayout) findViewById(R.id.lay2);
        lay_recipe3 = (RelativeLayout) findViewById(R.id.lay3);
        lay_recipe4 = (RelativeLayout) findViewById(R.id.lay4);
        lay_recipe5 = (RelativeLayout) findViewById(R.id.lay5);
        lay_recipe6 = (RelativeLayout) findViewById(R.id.lay6);
        lay_recipe7 = (RelativeLayout) findViewById(R.id.lay7);

        getSupportActionBar().setTitle(getString(R.string.app_name));

        lay_recipe1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.Dosa_title);
                recipe_imagename="andhra_dosa";
                recipe_shortdescription = getResources().getString(R.string.Dosa_shortdescription);
                about_recipe = getResources().getString(R.string.Dosa_recipetype);
                recipe_ingredients = getResources().getString(R.string.Dosa_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.Dosa_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.Dosa_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.MeduVada_title);
                recipe_imagename="andhra_vada";
                recipe_shortdescription = getResources().getString(R.string.MeduVada_shortdescription);
                about_recipe = getResources().getString(R.string.MeduVada_recipetype);
                recipe_ingredients = getResources().getString(R.string.MeduVada_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.MeduVada_makinginstructions);
                recipe_makingvideoURL = null;
                callingActivity();
            }
        });

        lay_recipe3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.EggCurry_title);
                recipe_imagename="andhra_eggcurry";
                recipe_shortdescription = getResources().getString(R.string.EggCurry_shortdescription);
                about_recipe = getResources().getString(R.string.EggCurry_recipetype);
                recipe_ingredients = getResources().getString(R.string.EggCurry_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.EggCurry_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.EggCurry_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.EggplantTomatoCurry_title);
                recipe_imagename="andhra_brinjal";
                recipe_shortdescription = getResources().getString(R.string.EggplantTomatoCurry_shortdescription);
                about_recipe = getResources().getString(R.string.EggplantTomatoCurry_recipetype);
                recipe_ingredients = getResources().getString(R.string.EggplantTomatoCurry_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.EggplantTomatoCurry_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.EggplantTomatoCurry_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.Rasam_title);
                recipe_imagename="rasam";
                recipe_shortdescription = getResources().getString(R.string.Rasam_shortdescription);
                about_recipe = getResources().getString(R.string.Rasam_recipetype);
                recipe_ingredients = getResources().getString(R.string.Rasam_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.Rasam_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.Rasam_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.FishFry_title);
                recipe_imagename="fishfry";
                recipe_shortdescription = getResources().getString(R.string.FishFry_shortdescription);
                about_recipe = getResources().getString(R.string.FishFry_recipetype);
                recipe_ingredients = getResources().getString(R.string.FishFry_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.FishFry_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.FishFry_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.MangoPickle_title);
                recipe_imagename="mangopickle";
                recipe_shortdescription = getResources().getString(R.string.MangoPickle_shortdescription);
                about_recipe = getResources().getString(R.string.MangoPickle_recipetype);
                recipe_ingredients = getResources().getString(R.string.MangoPickle_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.MangoPickle_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.MangoPickle_makingvideoURL);
                callingActivity();
            }
        });
    }

    public void callingActivity() {
        Intent intentrecipemaking = new Intent(AndhraRecipesActivity.this, RecipeMakingActivity.class);
        intentrecipemaking.putExtra("recipe_title", recipe_title);
        intentrecipemaking.putExtra("recipe_imagename", recipe_imagename);
        intentrecipemaking.putExtra("recipe_shortdescription", recipe_shortdescription);
        intentrecipemaking.putExtra("about_recipe", about_recipe);
        intentrecipemaking.putExtra("recipe_ingredients", recipe_ingredients);
        intentrecipemaking.putExtra("recipe_makinginstructions", recipe_makinginstructions);
        intentrecipemaking.putExtra("recipe_makingvideoURL", recipe_makingvideoURL);
        startActivity(intentrecipemaking);
    }
}
