package purnima.indianfoodrecipe;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;

public class HyderabadRecipesActivity extends AppCompatActivity{

    RelativeLayout lay_recipe1;
    RelativeLayout lay_recipe2;
    RelativeLayout lay_recipe3;
    RelativeLayout lay_recipe4;
    RelativeLayout lay_recipe5;

    String recipe_title=null,recipe_shortdescription = null, about_recipe = null, recipe_ingredients = null, recipe_makinginstructions = null;
    String recipe_makingvideoURL=null;
    String recipe_imagename=null;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hyderabadrecipes);
        Intent intenthyderabad = getIntent();

        lay_recipe1 = (RelativeLayout) findViewById(R.id.lay1);
        lay_recipe2 = (RelativeLayout) findViewById(R.id.lay2);
        lay_recipe3 = (RelativeLayout) findViewById(R.id.lay3);
        lay_recipe4 = (RelativeLayout) findViewById(R.id.lay4);
        lay_recipe5 = (RelativeLayout) findViewById(R.id.lay5);

        getSupportActionBar().setTitle(getString(R.string.app_name));

        lay_recipe1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.HyderabadiChickenBiryani_title);
                recipe_imagename="hyderabadbiryani";
                recipe_shortdescription = getResources().getString(R.string.HyderabadiChickenBiryani_shortdescription);
                about_recipe = getResources().getString(R.string.HyderabadiChickenBiryani_recipetype);
                recipe_ingredients = getResources().getString(R.string.HyderabadiChickenBiryani_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.HyderabadiChickenBiryani_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.HyderabadiChickenBiryani_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.ButterChicken_title);
                recipe_imagename="butterchicken";
                recipe_shortdescription = getResources().getString(R.string.ButterChicken_shortdescription);
                about_recipe = getResources().getString(R.string.ButterChicken_recipetype);
                recipe_ingredients = getResources().getString(R.string.ButterChicken_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.ButterChicken_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.ButterChicken_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.CornTikkiPatties_title);
                recipe_imagename="corntikkipatties";
                recipe_shortdescription = getResources().getString(R.string.CornTikkiPatties_shortdescription);
                about_recipe = getResources().getString(R.string.CornTikkiPatties_recipetype);
                recipe_ingredients = getResources().getString(R.string.CornTikkiPatties_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.CornTikkiPatties_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.CornTikkiPatties_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.CurdRice_title);
                recipe_imagename="curdrice";
                recipe_shortdescription = getResources().getString(R.string.CurdRice_shortdescription);
                about_recipe = getResources().getString(R.string.CurdRice_recipetype);
                recipe_ingredients = getResources().getString(R.string.CurdRice_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.CurdRice_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.CurdRice_makingvideoURL);
                callingActivity();
            }
        });

        lay_recipe5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recipe_title= getResources().getString(R.string.HyderabadiBagaraBaingan_title);
                recipe_imagename="hyderabadibagarabaingan";
                recipe_shortdescription = getResources().getString(R.string.HyderabadiBagaraBaingan_shortdescription);
                about_recipe = getResources().getString(R.string.HyderabadiBagaraBaingan_recipetype);
                recipe_ingredients = getResources().getString(R.string.HyderabadiBagaraBaingan_ingredients);
                recipe_makinginstructions = getResources().getString(R.string.HyderabadiBagaraBaingan_makinginstructions);
                recipe_makingvideoURL = getResources().getString(R.string.HyderabadiBagaraBaingan_makingvideoURL);
                callingActivity();
            }
        });
    }

    public void callingActivity() {
        Intent intentrecipemaking = new Intent(HyderabadRecipesActivity.this, RecipeMakingActivity.class);
        intentrecipemaking.putExtra("recipe_title", recipe_title);
        intentrecipemaking.putExtra("recipe_imagename", recipe_imagename);
        intentrecipemaking.putExtra("recipe_shortdescription", recipe_shortdescription);
        intentrecipemaking.putExtra("about_recipe", about_recipe);
        intentrecipemaking.putExtra("recipe_ingredients", recipe_ingredients);
        intentrecipemaking.putExtra("recipe_makinginstructions", recipe_makinginstructions);
        intentrecipemaking.putExtra("recipe_makingvideoURL", recipe_makingvideoURL);
        startActivity(intentrecipemaking);
    }
}
